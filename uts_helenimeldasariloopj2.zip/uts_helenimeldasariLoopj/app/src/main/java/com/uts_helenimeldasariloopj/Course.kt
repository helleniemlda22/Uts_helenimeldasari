package com.uts_helenimeldasariloopj

import android.graphics.drawable.AnimatedImageDrawable
import androidx.core.view.NestedScrollingParentHelper
import java.security.cert.CertPath

data class Course(
    val title : String,
    val path : String,
    val image : String,
)
